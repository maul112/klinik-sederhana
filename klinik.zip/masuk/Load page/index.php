<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="logo">
                <img src="Frame 1171275126.png" alt="Logo">
            </div>
            <div class="spinner-container">
                <div class="spinner"></div>
        </div>
    </div>
</body>
</html>
