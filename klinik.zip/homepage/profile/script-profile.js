// document.getElementById('editButton').addEventListener('click', function() {
//     const formElements = document.querySelectorAll('#userForm input');
//     let isReadonly = formElements[0].hasAttribute('readonly');
//     formElements.forEach(element => {
//         if (isReadonly) {
//             element.removeAttribute('readonly');
//             element.style.backgroundColor = '#ffffff';
//         } else {
//             element.setAttribute('readonly', 'readonly');
//             element.style.backgroundColor = '#f8f9fa';
//         }
//     });

//     const button = document.getElementById('editButton');
//     if (button.textContent === 'edit') {
//         button.textContent = 'save';
//     } else {
//         button.textContent = 'edit';
//     }
// });


// const gambar = document.getElementById('gambar');
// gambar.addEventListener('change', function() {
//     alert('hello');
// })