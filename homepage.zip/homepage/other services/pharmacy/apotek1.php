<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHARMACY</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>PHARMACY</h1>
        </header>
        <div class="grid" >
            <a href="pills.php">
                <div class="card">
                    <div class="icon"><img src="assets-farm/pills.png" alt="Pills icon"></div>
                    <div class="content">
                        <h2>Pills</h2>
                    </div>
                </div>
            </a>
            <a href="External Medicine.php">
                <div class="card">
                    <div class="icon"><img src="assets-farm/external.png" alt="External Medicine icon"></div>
                    <div class="content">
                        <h2>External Medicine</h2>
                    </div>
                </div>
            </a>
            <a href="syrup.php">
                <div class="card">
                    <div class="icon"><img src="assets-farm/syrup.png" alt="Syrup icon"></div>
                    <div class="content">
                        <h2>Syrup</h2>
                    </div>
                </div>
            </a>
            <a href="Other Medications.php">
                <div class="card">
                    <div class="icon"><img src="assets-farm/other.png" alt="Other Medications icon"></div>
                    <div class="content">
                        <h2>ALL Medications</h2>
                    </div>
                </div>
            </a>
            <div class="upload-section">
                <h2>Upload Your Prescription</h2>
            </div>
            <br>
            <div class="card upload-card">
                <div class="icon"><img src="assets-farm/recipe.png" alt="Prescription icon"></div>
                <div class="content">
                    <h2>Have a Prescription?</h2>
                    <p>Upload here, and get medicines delivered.</p>
                </div>
            </div>
        </div>
    </div>

     
    <!-- Modal -->
    <div id="uploadModal" class="modal" style="display: none !important;">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Upload Your Prescription</h2>
            <form id="uploadForm">
                <label for="prescription" class="custom-file-upload">
                    Choose File
                </label>
                <input type="file" id="prescription" name="prescription" accept="image/*" required>
                <button type="submit">Upload</button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>