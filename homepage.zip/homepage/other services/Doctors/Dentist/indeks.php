<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_klinik");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Poli yang akan ditampilkan
$poli = 'Dentist';

// Query untuk mendapatkan data dokter beserta jadwalnya
$sql = "SELECT 
            dokter.id, 
            dokter.fullname, 
            dokter.username, 
            dokter.poli, 
            dokter.gambar, 
            GROUP_CONCAT(CONCAT(jadwal_dokter.hari_praktik, ' (', jadwal_dokter.jam_praktik, ')') SEPARATOR ', ') AS jadwal,
            MIN(jadwal_dokter.status) AS status 
        FROM dokter 
        JOIN jadwal_dokter ON dokter.id = jadwal_dokter.id_dokter 
        WHERE dokter.poli = '$poli'
        GROUP BY dokter.id";

// Eksekusi query dan cek hasilnya
$result = $conn->query($sql);
if (!$result) {
    die("Query error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>DOCTORS</h1>
        </header>
        <div class="filters">
            <a href="../indeks.php"><button class="filter-button">General</button></a>
            <a href="../Gastroenteritis/indeks.php"><button class="filter-button">Gastroenteritis</button></a>
            <a href="../Cardiologist/indeks.php"><button class="filter-button ">Cardiologist</button></a>
            <a href="../Orthopaedic/indeks.php"><button class="filter-button">Orthopaedic</button></a>
            <a href="../Dentist/indeks.php"><button class="filter-button active">Dentist</button></a>
            <a href="../Otology/indeks.php"><button class="filter-button">Otology</button></a>
        </div>
        <div class="doctor-list">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Path gambar dokter di folder userProfile
                    $gambarDokter = empty($row['gambar']) ? 'profile/Vector.png' : "../../../../userProfile/" . htmlspecialchars($row['gambar']);
                    ?>
                    <div class="doctor-card">
                        <img src="<?php echo $gambarDokter; ?>" alt="<?php echo htmlspecialchars($row['fullname']); ?>">
                        <div class="doctor-info">
                            <a href="../../book/book.php?poli=Dentist&dokter=<?php echo urlencode($row['username']); ?>">
                                <h2><?php echo htmlspecialchars($row['fullname']); ?></h2>
                            </a>
                            <p><?php echo htmlspecialchars($row['poli']); ?></p>
                            <p>Jadwal: <?php echo htmlspecialchars($row['jadwal']); ?></p>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p>Tidak ada dokter tersedia untuk kategori ini.</p>";
            }
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
