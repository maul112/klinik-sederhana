<?php

session_start();

$username = $_SESSION["username"];

$conn = mysqli_connect('localhost', 'root', '', 'db_klinik');
$temp = mysqli_query($conn, "SELECT * FROM antrian WHERE username = '$username' AND status = 'upcoming'");
// var_dump($temp);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="appointment.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="container-fluid d-flex justify-content-between align-items-center">
                <h1>APPOINTMENT</h1>
                <a class="d-block btn px-3 py-1" style="background: linear-gradient(274.42deg, #92A3FD 0%, #9DCEFF 124.45%); border-radius: 1rem;" href="../">Home</a>
            </div>
            <div class="tabs">
                <div class="tab active"><a href="upcoming.php">Upcoming</a></div>
                <div class="tab"><a href="completed.php">Completed</a></div>
                <div class="tab"><a href="visitReport.php">Visit Report</a></div>
            </div>
        </div>
        <div id="upcoming-appointments" class="appointments">
            <?php while($data = mysqli_fetch_assoc($temp)) :?>
            <div class="appointment-card">
                <div class="appointment-header">
                    <img src="DR Williem Smith.png" alt="DR William Smith">
                    <div class="appointment-details">
                        <h2><?= $data["dokter"]?></h2>
                        <div class="detail-container">
                            <div class="spesialis"><?= $data["poly"]?> |</div>
                            <div class="upcoming"><?= $data["status"]?></div>
                        </div>
                        <div class="date-time"><?= $data["date"]?> | <?= $data["hour"]?></div>
                    </div>
                </div>
                <div class="buttons">
                    <!-- <button class="btn cancel">Cancel Booking</button> -->
                    <a href="hapus.php?id=<?= $data["id"]?>" class="btn cancel pt-2">Cancel Booking</a>
                    <button class="btn reschedule"><a href="../other services/book/book.php?id=<?= $data["id"]?>">Reschedule</a></button>
                </div>
            </div>
            <?php endwhile?>
            <!-- <div class="appointment-card">
                <div class="appointment-header">
                    <img src="DR Janneth William.png" alt="DR Janneth William">
                    <div class="appointment-details">
                        <h2>DR Janneth William</h2>
                        <div class="detail-container">
                            <div class="spesialis">Obstetriciants |</div>
                            <div class="upcoming">Upcoming</div>
                        </div>
                        <div class="date-time">Aug 11, 2023 | 11:00 AM</div>
                    </div>
                </div>
                <div class="buttons">
                    <button class="btn cancel">Cancel Booking</button>
                    <button class="btn reschedule"><a href="#Book again">Reschedule</a></button>
                </div>
            </div>
            <div class="appointment-card">
                <div class="appointment-header">
                    <img src="DR Reinath Salsa.png" alt="DR Reinath Salsa">
                    <div class="appointment-details">
                        <h2>DR Reinath Salsa</h2>
                        <div class="detail-container">
                            <div class="spesialis">Apthalmologist |</div>
                            <div class="upcoming">Upcoming</div>
                        </div>
                        <div class="date-time">Aug 18, 2023 | 11:00 AM</div>
                    </div>
                </div>
                <div class="buttons">
                    <button class="btn cancel">Cancel Booking</button>
                    <button class="btn reschedule"><a href="#Book again">Reschedule</a></button>
                </div>
            </div>
            <div class="appointment-card">
                <div class="appointment-header">
                    <img src="DR Edith Farith.png" alt="DR Edith Farith">
                    <div class="appointment-details">
                        <h2>DR Edith Farith</h2>
                        <div class="detail-container">
                            <div class="spesialis">ENT |</div>
                            <div class="upcoming">Upcoming</div>
                        </div>
                        <div class="date-time">Aug 25, 2023 | 11:00 AM</div>
                    </div>
                </div>
                <div class="buttons">
                    <button class="btn cancel">Cancel Booking</button>
                    <button class="btn reschedule"><a href="#Book again" >Reschedule</a></button>
                </div>
            </div>
        </div> -->
        
    </div>
    <script src="appointment.js"></script>
</body>
</html>
