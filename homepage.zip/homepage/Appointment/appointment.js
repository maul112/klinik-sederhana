// document.addEventListener('DOMContentLoaded', () => {
//     const cancelButtons = document.querySelectorAll('.btn.cancel');
//     cancelButtons.forEach(button => {
//         button.addEventListener('click', (event) => {
//             const appointmentCard = event.target.closest('.appointment-card');
            
//             // Remove the appointment card from the upcoming appointments
//             appointmentCard.remove();

//             // Change the status text and styling
//             const statusDiv = appointmentCard.querySelector('.status');
//             statusDiv.textContent = 'Cancelled';
//             statusDiv.classList.remove('upcoming');
//             statusDiv.classList.add('cancelled');

//             // Change buttons
//             const rescheduleButton = appointmentCard.querySelector('.btn.reschedule');
//             const cancelButton = appointmentCard.querySelector('.btn.cancel');
//             rescheduleButton.remove();
//             cancelButton.textContent = 'Book Again';
//             cancelButton.classList.remove('cancel');
//             cancelButton.classList.add('book-again');

//             // Move the card to the cancelled section in cancelled.html
//             const cancelledAppointmentsSection = document.getElementById('cancelled-appointments');
//             cancelledAppointmentsSection.appendChild(appointmentCard);
//         });
//     });
// });