<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Klinik</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/album/">

    

    <!-- Bootstrap core CSS -->
<link href="./dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
  </head>
  <body>
      <header class="sticky-top">
        <div class="navbar navbar-expand-lg navbar-light bg-white">
            <div class="container">
              <a href="./index.html" class="navbar-brand d-flex align-items-center">
                <img src="/Klinik Kita Sehat/homepage/fitur/sidebar/kitasehat.png" width="100" class="mr-auto"/>
                <div class="grid">
                  <h1 class="mb-1">Klinik Kita Sehat</h1>
                  <small>Kenanga ave. no. 34 block h</small>
                </div>
              </a>
            </div>
        </div>

  </header>

    <main>

      <div class="album py-5 bg-light">
        <div class="container">
          <div class="row col-12 g-3">
            <div class="col-lg-9 col-sm-12">
              <div class="card shadow-sm rounded-3">
                <div class="card-body">
                  <p class="card-text p-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec placerat arcu odio, ut rutrum odio consectetur sed. Nunc hendrerit ex nec dui ullamcorper volutpat. Praesent id libero sed nisl lobortis dictum. Mauris sollicitudin dictum massa, in vehicula tellus posuere laoreet. Maecenas dolor erat, consequat a neque vitae, tempor cursus lacus. Mauris ut mauris id lectus vehicula accumsan. Nulla luctus, ligula sed tristique consequat, lacus tortor auctor massa, vel tempus purus nunc id nulla. Nunc tempus ultrices leo, in placerat velit condimentum eu. Vivamus in nunc at ipsum consectetur dapibus. Aliquam ut orci efficitur, pharetra purus ac, interdum sem. Vestibulum id condimentum ligula. Suspendisse vulputate scelerisque mi, eu aliquet ante feugiat eget. Phasellus aliquam sapien vel fermentum condimentum. Vivamus tincidunt maximus magna ac fringilla. Donec cursus est id felis feugiat laoreet.

                    Nam cursus massa ac euismod viverra. Aenean faucibus lorem nec suscipit rutrum. Sed felis urna, aliquam vitae consectetur sed, auctor sed tortor. Integer in ex ante. In ac dapibus augue. Donec sagittis risus id aliquam feugiat. Pellentesque porttitor risus in quam lacinia, at finibus massa placerat. In sagittis id ipsum sed viverra. Phasellus diam risus, hendrerit vitae malesuada ut, maximus vel est. Morbi elit mi, ultrices vel dolor eget, efficitur dignissim justo. Phasellus sit amet sem sit amet sapien blandit lacinia iaculis sed ex. Aliquam ut risus et ipsum convallis fringilla. Integer sit amet efficitur lorem. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;
                    
                    Etiam viverra lectus ac ligula hendrerit accumsan. Quisque vel felis orci. Ut suscipit neque felis, nec pellentesque neque blandit sed. Pellentesque venenatis ligula id urna dictum, et sodales risus bibendum. Integer in urna ligula. Fusce tempor arcu et dolor ullamcorper maximus. Sed hendrerit dolor quam, ac scelerisque sem lobortis in. Fusce at interdum neque, eu euismod magna. Ut quis felis vel tellus euismod congue. Suspendisse in congue dolor, ac pharetra ex. Cras eu turpis sapien. Aliquam a ex vitae eros facilisis egestas pulvinar ac mauris. Maecenas bibendum bibendum ultrices. Duis consectetur enim vel elit aliquam, a tempor purus ullamcorper. Vivamus iaculis id nisl a pretium.
                    
                    Etiam vestibulum orci ut augue suscipit, et lacinia dui rhoncus. Pellentesque sed sapien porta, efficitur tortor id, pharetra augue. Cras ut lobortis dui, vel sodales tellus. Aenean vitae nisi odio. Quisque id interdum erat, eu consectetur dui. Fusce nisi nulla, semper quis imperdiet at, finibus id urna. Curabitur scelerisque at purus vel lobortis. Aliquam sit amet turpis eget mi dignissim facilisis. Nam cursus massa non ante pellentesque, eu pharetra metus blandit. Integer vel pretium mauris. Phasellus posuere euismod dui, quis feugiat nibh. Proin viverra porttitor ligula, in tincidunt dui vehicula facilisis. Nam sodales purus ac ipsum posuere, ut commodo lorem rutrum.
                    
                    In hac habitasse platea dictumst. Phasellus vel leo dignissim, tristique augue id, malesuada augue. Proin vel nunc at orci lacinia auctor. Sed sodales, lacus a luctus rutrum, risus felis elementum nisl, sit amet vestibulum sapien nibh porttitor ligula. Donec pulvinar, elit eu scelerisque dictum, orci erat pharetra ex, ac convallis metus augue id tellus. Morbi hendrerit vehicula nibh, vitae semper mi dignissim ut. Phasellus at accumsan nunc, ut aliquet odio.
                    
                    Aliquam laoreet dolor quam, quis semper nulla posuere id. In ultrices maximus tellus in imperdiet. Morbi suscipit lacinia imperdiet. Integer dignissim lacus diam, sed convallis augue imperdiet non. Sed fringilla felis mauris, vel commodo lorem posuere vel. Sed volutpat lorem justo, id porttitor massa consequat id. Vestibulum vel mi nisi.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12">
              <div class="card shadow-sm p-2 rounded rounded-2">
                <div class="card-body">
                  <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h5>
                  <div class="d-flex justify-content-between align-items-center">
                    <small>05 Agustus 2023</small>
                    <small class="text-muted">Zask</small>
                  </div>
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <a class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-primary">Read More</button>
                    </div>
                    <small class="text-muted">9 mins</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </main>

    <footer class="text-muted py-5">
      <div class="container">
        <p class="float-end mb-1">
          <a href="#">Back to top</a>
        </p>
      </div>
    </footer>

    <script src="./dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
