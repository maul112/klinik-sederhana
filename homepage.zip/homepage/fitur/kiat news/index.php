<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiat News</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: left;
            padding: 20px 0;
        }
        .header h1 {
            font-size: 36px;
            margin: 0;
            color: #333;
        }
        .header h1 span {
            color: #9b8af7;
        }
        .content {
            text-align: left;
            margin-bottom: 20px;
        }
        .grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            background-color: #cce0ff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            flex: 1;
            min-width: 280px;
            max-width: 300px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-10px);
        }
        .card h3 {
            margin-top: 0;
            font-size: 24px;
            color: #333;
        }
        .card p {
            font-size: 14px;
            color: #666;
        }
        .card .date {
            font-size: 14px;
            color: #999;
            margin-bottom: 10px;
        }
        .card .read-more {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #fff;
            color: #666;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ccc;
            transition: background-color 0.2s, color 0.2s;
        }
        .card .read-more:hover {
            background-color: #9b8af7;
            color: #fff;
            border-color: #9b8af7;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>KIAT <span>NEWS</span></h1>
        </div>
        <div class="content">
            <p>Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elit. Sed Pellentesque Leo Nec Aenean Maecenas Odio Tempus Id. Mauris, Elementum Est Egestas Tincidunt Pellentesque. Tempus Massa Rhoncus Velit Nec. Lorem Purus Est Facilisis Quam Lorem Amet, Nunc Lectus. Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elit. Sed Pellentesque Leo Nec Aenean Maecenas Odio Tempus Id. Mauris, Elementum Est Egestas Tincidunt Pellentesque. Tempus Massa Rhoncus Velit Nec. Lorem Purus Est Facilisis Quam Lorem Amet, Nunc Lectus.</p>
        </div>
        <div class="grid">
            <div class="card">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 1, 2024, 7:13 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card" style="background-color: #d8c1ff;">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 4, 2024, 11:00 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card" style="background-color: #b9b3ff;">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 8, 2024, 13:33 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 15, 2024, 9:43 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card" style="background-color: #d8c1ff;">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 17, 2024, 6:23 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card" style="background-color: #b9b3ff;">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Mei 20, 2024, 17:00 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            <div class="card" style="background-color: #b9b3ff;">
                <h3>Helping Seniors Learn New Hobbies</h3>
                <div class="date">Jul 1, 2024, 10:30 AM</div>
                <p>Lorem ipsum dolor sit amet, vel te doming repudiare, eum nihil voluptatem ne, tollit.</p>
                <a href="kiat news detail.php" class="read-more">Read More</a>
            </div>
            
            
        </div>
    </div>
</body>
</html>
